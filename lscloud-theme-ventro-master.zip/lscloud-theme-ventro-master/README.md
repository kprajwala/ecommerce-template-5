Ventro Theme For LemonStand Cloud
=================

A simple responsive theme for LemonStand thats easy to customize.

It's based on the Bootstrap CSS framework.

# Features

* Responsive / mobile-friendly
* Upload your own logo and banner image
* Upload your own favicon.ico image
* Simple checkout pages
* Breadcrumbs
* Supports product options, variants, attributes
* Guest and registered checkout
* "Copy billing information" on checkout

[Visit LemonStand](www.lemonstand.com)

[LemonStand Docs](docs.lemonstand.com)